Richsoft VBZip Version 1
-------- ----- ------- -

VBZip is a ActiveX control designed to allow developers to add standard ZIP compression and decompression to their own application.

Installation
------------

The following files are required when using the control

* VBZip_Control.ocx - The actuall ActiveX control
* Zipit.dll } Dll required to access InfoZip dlls (Working on how to by-pass this in later versions)
* Zipdll.dll } Info-Zip dlls
* Unzdll.dll }

PLEASE NOTE
------ ----

* Recursing Sub folders still does not do anything

Legal Stuff
----- -----
Info-Zip Dlls (Zipdll.dll & Unzdll.dll)
Copyright (c) 1990-1999 Info-ZIP.  All rights reserved.
Please read licence.txt for more information

Although I am releasing this software as freeware, if you use any part of it please
give credit.   A phrase such as 'Uses code from Richsoft Computing www.richsoftcomputing.btinternet.co.uk' is sufficent.

Good luck - More detailed documentation is on the way

Richard Southey
Richsoft Computing (c)2001
