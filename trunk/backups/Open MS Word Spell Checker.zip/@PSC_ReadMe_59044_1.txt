Title: Open MS Word Spell Checker
Description: This code will allow you to open the MS word Spell checker.
I did not write this code it was taken from another website I just made it into a project.
Please do not vote for this code but please leave any comments you may have.
I did not upload a Screen shot because there is no need for one.
When I first uploaded this I forgot to change the text box name in the code it is fixed now.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59044&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
