Title: Disable Max and Min buttons on a MDIform
Description: I am working on a new project a email reader program and I needed the MDI form to be able to disable the Max Button. So I looked all over the net and came accross some code. I couldn't find any good examples on PSC so I decided to make this one and upload it.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=57159&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
