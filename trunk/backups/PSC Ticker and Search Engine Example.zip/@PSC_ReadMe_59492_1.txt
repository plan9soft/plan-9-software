Title: PSC Ticker and Search Engine Example
Description: Ok I tried uploading this code earlier but when I tried and check it PSC said it was corrupt so I am uploading it again
This is part of a search engine program I am working on for a Mozilla Browser I am working on. This code here shows how to add the PSC Ticker to your program. And how to change between each ticker when you switch languages to search in. Some of the ticker was taken from PSC all the search code was written by me.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59492&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
