Title: Msn 8 About Box
Description: Hello this is my first post to planet source code. What this code will do is let you add a MSN 8 style About box to your program. 
I have added a screenshot in the zip of the original msn 8 about box so you can see the diffrence
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=48912&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
