MS Agent Animations (Updated)

Original Code by Me(Sorcerer)

I Originally submitted this code back in 2004 the old code is still here on Planet Souce code, I have also included a zip with the Original Code. I have updated the code a bit and added a few new features.

Now instead of the Agents being hard coded into the program like before the source now detects all your installed characters
and fills the combobox with there names.

I have also added a little error handeling code, the main reason for this update is I am working on a new MS Agent character
viewer program. I had to go through my old MS Agent source for idea's and I found this code and decided to update it.

Make Sure Atleast Merlin is Installed.