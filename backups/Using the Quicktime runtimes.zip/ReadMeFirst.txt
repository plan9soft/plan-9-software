Program Name: Quicktime Player
Author: Sorcerer
Build Date: 03/16/2004
 
Description:
  Ok I was trying to find info on how to use quick time in a media
  Player program I am working on and couldn't
 
  So I installed quicktime and started messing with the runtimes
  took me a few minutes to find the right ocx and a few minutes
  more to figure out the right code to open the file
  At this time this just basicly opens a apple movie file and plays it
  I have added the Apple runtime I used to make this and the
  sample apple mov that came with quicktime to show the code in action.


Ok just rename the file QTPlugin.nat to QTPlugin.ocx if you get a runtime error just point vb to the ocx where you put it.

Ok The first Attempt to upload this to PSC they deleted the runtime so I have zipped it into its own zip.

