Title: Using the Quicktime runtimes
Description: This code here at this time will show you how to open and play a quicktime, mov file. The reason I have uploaded this code is I was looking for code to play quicktime files in a media player I am working on.
I figured out how to open a mov file using the apple runtime. I will be adding to this code soon I just decided to upload the basic code.
Later versions will have allot more features.
I have added a readme it tells you everything you need to know like where the quicktime runtime is. I used Quicktime 6.5 runtimes in this example.
PSC will not allow me to upload the file with the runtime the runtime used was QTPlugin.ocx version 6.5 if you don't have Quicktime and don't want to download it then post a mess here and I will upload the dll to my site.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=52419&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
