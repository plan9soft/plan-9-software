Title: Using the Double Agent Control
Description: This Code will show you how to use the Double Agent Control to replace the MS Agent Control.
Please Download the 32bit installer for the Control here http://sourceforge.net/projects/doubleagent/
You must use the 32bit even if your running a 64 bit OS. I have tested this on Windows 7 x64 and Windows Xp 32bit
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=73376&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
